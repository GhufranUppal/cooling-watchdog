SELECT site, risk_score,
       next_window_start_ts,
       COALESCE(
         next_window_starts_in_h,
         GREATEST(0, FLOOR(EXTRACT(EPOCH FROM(next_window_start_ts - now()))/3600))
       ) AS starts_in_h
FROM risk_now
WHERE site = :site;
