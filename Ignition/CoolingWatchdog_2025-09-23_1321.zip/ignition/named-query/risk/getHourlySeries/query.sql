SELECT
  ts AS "Date",
  ((CASE WHEN temperature_risk THEN 1 ELSE 0 END)
   + (CASE WHEN wind_risk         THEN 1 ELSE 0 END)
   + (CASE WHEN humidity_risk     THEN 1 ELSE 0 END)) AS "Risk Score"
FROM risk_hourly

