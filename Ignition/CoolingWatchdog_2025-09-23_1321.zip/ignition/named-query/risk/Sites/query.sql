SELECT site
FROM (
  SELECT DISTINCT site FROM public.risk_now
  UNION
  SELECT DISTINCT site FROM public.risk_windows
  UNION
  SELECT DISTINCT site FROM public.risk_hourly
) s
ORDER BY site;
