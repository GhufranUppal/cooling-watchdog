SELECT
  start_ts         AS "Start Time",
  end_ts           AS "End Time",
  duration_h       AS "Duration(hours)",
  triggers         AS "Risk Triggers",
  risk_score       AS "Risk Score"
FROM risk_windows
WHERE site = :site
ORDER BY start_ts;
